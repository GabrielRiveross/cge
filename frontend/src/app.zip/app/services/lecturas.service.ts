import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

export interface LecturaIn {
  id_medidor: number;
  anio: number;
  mes: number;
  lectura_actual: number;
  observacion?: string;
}

@Injectable({ providedIn: 'root' })
export class LecturasService {
  private base = `${environment.apiBase}/api/lecturas`;

  constructor(private http: HttpClient) {}

  registrar(data: LecturaIn) {
    return this.http.post<any>(this.base, data);
  }

  listarPorMedidor(id_medidor: number) {
    return this.http.get<any[]>(`${this.base}/por-medidor/${id_medidor}`);
  }
}
