import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { LecturasService } from '../../services/lecturas.service';

@Component({
  selector: 'app-lecturas',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatFormFieldModule, MatInputModule, MatButtonModule, MatSnackBarModule, MatTableModule
  ],
  templateUrl: './lecturas.component.html'
})
export class LecturasComponent implements OnInit {
  private fb = inject(FormBuilder);
  private svc = inject(LecturasService);
  private snack = inject(MatSnackBar);

  form = this.fb.group({
    id_medidor: [Number(localStorage.getItem('ultimoMedidor')) || null, [Validators.required]],
    anio: [new Date().getFullYear(), [Validators.required, Validators.min(2000), Validators.max(2100)]],
    mes: [new Date().getMonth() + 1, [Validators.required, Validators.min(1), Validators.max(12)]],
    lectura_actual: [null, [Validators.required, Validators.min(0)]],
    observacion: ['']
  });

  displayedColumns = ['anio', 'mes', 'kwh', 'obs'];
  lecturas: any[] = [];

  ngOnInit(): void {
    const id = this.form.value.id_medidor;
    if (id) this.cargar(id);
  }

  private cargar(id_medidor: number) {
    localStorage.setItem('ultimoMedidor', String(id_medidor));
    this.svc.listarPorMedidor(id_medidor).subscribe({
      next: d => this.lecturas = d,
      error: e => this.snack.open(e?.error?.detail || 'Error al listar', 'Cerrar', { duration: 3000 })
    });
  }

  listar() {
    const id = this.form.value.id_medidor!;
    this.cargar(id);
  }

  registrar() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.snack.open('Revisa los campos', 'Cerrar', { duration: 2500 });
      return;
    }
    this.svc.registrar(this.form.value as any).subscribe({
      next: _ => {
        this.snack.open('Lectura registrada', 'OK', { duration: 2000 });
        this.listar();
      },
      error: e => {
        const msg = e?.status === 409 ? 'Ese mes ya tiene lectura' : (e?.error?.detail || 'Error al registrar');
        this.snack.open(msg, 'Cerrar', { duration: 3000 });
      }
    });
  }
}
