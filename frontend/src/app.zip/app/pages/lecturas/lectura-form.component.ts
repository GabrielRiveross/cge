import { Component, OnInit, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { LecturasService, LecturaCreate } from '../../services/lecturas.service';
import { MedidoresService } from '../../services/medidores.service';

type HistItem = { anio: number; mes: number; lectura_kwh: number };

@Component({
  selector: 'app-lectura-form',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatSnackBarModule
  ],
  templateUrl: './lectura-form.component.html'
})
export class LecturaFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private snack = inject(MatSnackBar);
  private lecturasSvc = inject(LecturasService);
  private medidoresSvc = inject(MedidoresService);

  medidores: any[] = [];
  cargando = false;

  // ✅ propiedad que faltaba
  historial: HistItem[] = [];

  form = this.fb.group({
    id_medidor: [null as number | null, [Validators.required]],
    anio: [new Date().getFullYear(), [Validators.required, Validators.min(2000), Validators.max(2100)]],
    mes: [new Date().getMonth() + 1, [Validators.required, Validators.min(1), Validators.max(12)]],
    lectura_kwh: [null as number | null, [Validators.required, Validators.min(0)]],
  });

  ngOnInit(): void {
    // Cargar medidores para el select
    this.medidoresSvc.listar().subscribe({
      next: (res: any[]) => this.medidores = res || [],
      error: () => this.snack.open('No se pudieron cargar los medidores', 'Cerrar', { duration: 2500 })
    });

    // Cargar historial cuando cambie el medidor
    this.form.controls.id_medidor.valueChanges.subscribe((id) => {
      if (id != null) this.cargarHistorial(Number(id));
      else this.historial = [];
    });
  }

  private cargarHistorial(id_medidor: number): void {
    // Ajusta el método según tu servicio: listar / listarPorMedidor / historial, etc.
    // Ejemplo genérico:
    const obs = (this.lecturasSvc as any).listarPorMedidor?.(id_medidor)
      ?? (this.lecturasSvc as any).historial?.(id_medidor)
      ?? (this.lecturasSvc as any).listar?.({ id_medidor });

    if (!obs || typeof obs.subscribe !== 'function') {
      // Si tu servicio todavía no tiene endpoint de historial, evita romper el template
      this.historial = [];
      return;
    }

    obs.subscribe({
      next: (items: HistItem[]) => this.historial = items ?? [],
      error: () => {
        this.historial = [];
        this.snack.open('No se pudo cargar el historial', 'Cerrar', { duration: 2500 });
      }
    });
  }

  registrar(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.snack.open('Completa los campos requeridos', 'Cerrar', { duration: 2500 });
      return;
    }

    const payload: LecturaCreate = {
      id_medidor: Number(this.form.value.id_medidor),
      anio: Number(this.form.value.anio),
      mes: Number(this.form.value.mes),
      lectura_kwh: Number(this.form.value.lectura_kwh)
    };

    this.cargando = true;
    this.lecturasSvc.crear(payload).subscribe({
      next: _ => {
        this.cargando = false;
        this.snack.open('Lectura registrada', 'OK', { duration: 2000 });

        // refrescar historial y limpiar solo el campo de lectura
        const id = Number(this.form.value.id_medidor);
        if (id) this.cargarHistorial(id);
        this.form.patchValue({ lectura_kwh: null });
      },
      error: e => {
        this.cargando = false;
        const detail = e?.error?.detail;
        const msg = typeof detail === 'string'
          ? detail
          : Array.isArray(detail) ? detail.map((x: any) => x?.msg || JSON.stringify(x)).join(' • ')
            : 'No se pudo registrar la lectura';
        this.snack.open(msg, 'Cerrar', { duration: 3500 });
      }
    });
  }
}
