import { Routes } from '@angular/router';
import { BoletasComponent } from './pages/boletas/boletas.component';
import { ClientesListComponent } from './pages/clientes/clientes-list.component';
import { ClienteFormComponent } from './pages/clientes/cliente-form.component';
import { MedidoresListComponent } from './pages/medidores/medidores-list.component';
import { MedidorFormComponent } from './pages/medidores/medidor-form.component';
import { LecturasComponent } from './pages/lecturas/lecturas.component';

export const routes: Routes = [
  { path: '', redirectTo: 'boletas', pathMatch: 'full' },

  { path: 'boletas', component: BoletasComponent },

  { path: 'clientes', component: ClientesListComponent },
  { path: 'clientes/nuevo', component: ClienteFormComponent },
  { path: 'clientes/editar/:id', component: ClienteFormComponent },

  { path: 'medidores', component: MedidoresListComponent },
  { path: 'medidores/nuevo', component: MedidorFormComponent },
  { path: 'medidores/editar/:id', component: MedidorFormComponent },

  { path: 'lecturas', component: LecturasComponent },

  { path: '**', redirectTo: 'boletas' }
];
